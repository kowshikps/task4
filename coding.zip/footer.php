
<div class="page-container row-fluid">
  <div class="page-sidebar mini" id="main-menu"> 
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper"> 
      <ul>  
        <li class=""> <a href="javascript:;"> <i class="fa fa-users"></i> <span class="title">User Management</span> <span class="arrow "></span> </a>
          <ul class="sub-menu">
            <li> <a href="add-user.php"> Add User </a> </li>
            <li> <a href="user-management.php"> Manage Users</a> </li>
          </ul>
        </li> 
      </ul>
      
    </div>
  </div>